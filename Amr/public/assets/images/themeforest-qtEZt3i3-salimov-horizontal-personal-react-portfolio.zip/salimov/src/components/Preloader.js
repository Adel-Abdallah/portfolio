const Preloader = () => {
  return (
    <div id="preloader" className="preloaded">
      <div className="line" />
    </div>
  );
};
export default Preloader;
