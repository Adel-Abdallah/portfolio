const ScrollBar = () => {
  return (
    <div className="scroll-progress hide-mobile">
      <div>
        <div />
      </div>
    </div>
  );
};
export default ScrollBar;
